Nathan Hamilton
Matthew Hopkins
Forrest Wallace

Shortcomings:
Our c program handles names, numbers, and input/output files properly. However, we were unable to successfully implement password hashing
functionality. Thus, CodeDefender.c stops after prompting for an output file and printing to said file.